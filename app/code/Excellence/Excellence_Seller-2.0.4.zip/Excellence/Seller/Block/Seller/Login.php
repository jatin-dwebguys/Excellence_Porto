<?php
/**
 * Copyright © 2015 Excellence . All rights reserved.
 */
namespace Excellence\Seller\Block\Seller;
use Excellence\Seller\Block\BaseBlock;
class Login extends BaseBlock
{
	public $hello='Hello World';
	
}
