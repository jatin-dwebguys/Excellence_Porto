<?php
/**
 * Copyright © 2015 Excellence . All rights reserved.
 */
namespace Excellence\Filter\Block\Filter;

class Index extends \Magento\Framework\View\Element\Template
{  

	
   //  public function __construct(
   //     \Magento\Eav\Model\Config $eavConfig
   // ) {
  
   //  $this->eavConfig = $eavConfig;
   
   //   }
	
	

    public function getFilters(){

    $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
    $EavModel = $objectManager->create('Magento\Catalog\Model\ResourceModel\Eav\Attribute');

     $attribute_id = array('169', '170','171','172' ,'173');
     return $EavModel->getCollection()->addFieldToFilter('attribute_id', array('in' => $attribute_id));
    }
  
  //  public function optionAll($attributeCode){
  //  	$attribute = $this->eavConfig->getAttribute('year', $attributeCode);
  // $options = $attribute->getSource()->getAllOptions();
  //  return $options;
  //  }

}
